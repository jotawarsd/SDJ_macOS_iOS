//header files
#import <foundation/foundation.h>
#import <cocoa/cocoa.h>

#import <QuartzCore/CVDisplayLink.h>

#import <OpenGL/gl3.h>
#import <OpenGL/gl3ext.h>

#import "vmath.h"
using namespace vmath;

CVReturn myDisplayLinkCallback(CVDisplayLinkRef, const CVTimeStamp *, const CVTimeStamp *, CVOptionFlags, CVOptionFlags *, void *);

//global variable declarations
FILE *gpFile = NULL;

//interface declarations
@interface AppDelegate:NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

//Programmable pipeline related global variables
GLuint shaderProgramObject;

enum
{
	SDJ_ATTRIBUTE_POSITION = 0,
	SDJ_ATTRIBUTE_COLOR,
	SDJ_ATTRIBUTE_NORMAL,
	SDJ_ATTRIBUTE_TEXTURE0
};

GLuint vao;
GLuint vbo_position;
GLuint vbo_normals;

//uniforms
GLuint modelMatrixUniform;
GLuint viewMatrixUniform;
GLuint projectionMatrixUniform;

//light uniforms
GLuint ldUniform;
GLuint kdUniform;
GLuint lightPositionUniform;
GLuint lightingEnabledUniform;

mat4 perspectiveProjectionMatrix;
//light array definitions
GLfloat lightDiffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat materialDiffuse[] = { 0.5f, 0.5f, 0.5f, 1.0f };
GLfloat lightPosition[] = { 2.0f, 2.0f, 2.0f, 1.0f };

bool bLight = false;
bool gbFullscreen = false;

float angleCube = 0.0;

@interface GLView:NSOpenGLView
@end

//entry point function
int main (int argc, char *argv[])
{
	//code
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];     //create autorelease pool
	NSApp = [NSApplication sharedApplication];

	//create app delegate object
	AppDelegate *appDelegate = [[AppDelegate alloc] init];

	//give the app delegate to NSApp
	[NSApp setDelegate:appDelegate];

	//start run(game) loop
	[NSApp run];

	//tell autorelease pool to release all objects created by this application
	[pool release];

	return 0;
}

//implementation of app delegate
@implementation AppDelegate 
	{
		@private
		NSWindow *window;
		GLView *view;
	}

	-(void)applicationDidFinishLaunching:(NSNotification *)notification
	{
		//code
		NSBundle *appBundle = [NSBundle mainBundle];
		NSString *appDirPath = [appBundle bundlePath];
		NSString *parentDirPath = [appDirPath stringByDeletingLastPathComponent];
		NSString *logFileNameWithPath = [NSString stringWithFormat:@"%@/Log.txt",parentDirPath];
		const char *pszLogFileNameWithPath = [logFileNameWithPath UTF8String];

		gpFile = fopen(pszLogFileNameWithPath, "w");
		if (gpFile == NULL)
			[NSApp terminate:self];
		fprintf(gpFile, "Program Started Successfully!!\n");

		NSRect rect = NSMakeRect(0.0, 0.0, 800.0, 600.0);

		window = [[NSWindow alloc]initWithContentRect:rect
			styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable
			backing:NSBackingStoreBuffered
			defer:NO];
		
		[window setTitle:@"macOS Window : SDJ"];

		//set background color
		NSColor *bkColor = [NSColor blackColor];
		[window setBackgroundColor:bkColor];

		view = [[GLView alloc]initWithFrame:rect];
		[window setContentView:view];

		[window center];		//center the window
		[window setDelegate:self];		//set window's delegate to this object
		[window makeKeyAndOrderFront:self];
	}

	-(void)applicationWillTerminate:(NSNotification *)notification
	{
		//code
		if (gpFile)
		{
			fprintf(gpFile, "Program Terminated Successfully!!\n");
			fclose(gpFile);
			gpFile = NULL;
		}
	}

	-(void)windowWillClose:(NSNotification *)notification
	{
		//code
		[NSApp terminate:self];
	}

	-(void)dealloc
	{
		//code
		if (view)
		{
			[view release];
			view = nil;
		}

		if (window)
		{
			[window release];
			window = nil;
		}

		[super dealloc];
	}
@end


//implement GLView
@implementation GLView
	{
		@private
		CVDisplayLinkRef displayLink;
	}

	-(id)initWithFrame:(NSRect)frame
	{
		//code  
		self = [super initWithFrame:frame];
		if (self)
		{
		//initialize array of OpenGL pixel format attributes
			NSOpenGLPixelFormatAttribute openGLPixelFormatAttributes[] = 
			{
				NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,
				NSOpenGLPFAScreenMask, CGDisplayIDToOpenGLDisplayMask(kCGDirectMainDisplay),
				NSOpenGLPFAColorSize, 24,
				NSOpenGLPFADepthSize, 24,
				NSOpenGLPFAAlphaSize, 8,
				NSOpenGLPFANoRecovery, 
				NSOpenGLPFAAccelerated,
				NSOpenGLPFADoubleBuffer, 
				0
			};

		//create OpenGL pixel format using above attributes
			NSOpenGLPixelFormat *glPixelFormat = [[[NSOpenGLPixelFormat alloc] initWithAttributes:openGLPixelFormatAttributes]autorelease];
			if (glPixelFormat == nil)
			{
				fprintf(gpFile, "glPixelFormat creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//create OpenGL context using above pixel format
			NSOpenGLContext *glContext = [[[NSOpenGLContext alloc] initWithFormat:glPixelFormat shareContext:nil] autorelease];
			if (glContext == nil)
			{
				fprintf(gpFile, "glContext creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//set this view's pixel format to the above pixel format
			[self setPixelFormat:glPixelFormat];
		
		//set view's OpenGL context to above context
			[self setOpenGLContext:glContext];
		}
		
		return self;
	}

	//define getFrameForTime method which will be called by my displayLinkCallback
	-(CVReturn)getFrameForTime:(const CVTimeStamp *)outputTime
	{
		//code
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

		[self drawView];

		[pool release];

		return kCVReturnSuccess;
	}

	-(void)prepareOpenGL
	{
		//code
		[super prepareOpenGL];
		
		//make the openGL context as current context
		[[self openGLContext] makeCurrentContext];

		//set double buffer swapping interval to 1
		GLint swapInterval = 1;
		[[self openGLContext] setValues:&swapInterval forParameter:NSOpenGLCPSwapInterval];

		//openGL log
		fprintf(gpFile, "\n\n-----printGLInfo-----\n\n");
		fprintf(gpFile, "OpenGL Vendor: %s\n", glGetString(GL_VENDOR));
		fprintf(gpFile, "OpenGL Renderer: %s\n", glGetString(GL_RENDERER));
		fprintf(gpFile, "OpenGL Version: %s\n", glGetString(GL_VERSION));
		fprintf(gpFile, "GLSL Version: %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

		fprintf(gpFile, "\n\n");

		//call initialize
		[self initialize];

		//create, configure, start display link
		//step 1
		CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);
		
		//step 2
		CVDisplayLinkSetOutputCallback(displayLink, &myDisplayLinkCallback, self);

		//step 3
		CGLPixelFormatObj cglPixelFormat = (CGLPixelFormatObj)[[self pixelFormat] CGLPixelFormatObj];

		//step 4
		CGLContextObj cglContext = (CGLContextObj)[[self openGLContext] CGLContextObj];

		//step 5
		CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);

		//step 6
		CVDisplayLinkStart(displayLink);
		
	}

	-(void)drawRect:(NSRect)dirtyRect
	{
		//code
		[self drawView];
	}

	-(void)drawView
	{
		//code
		[[self openGLContext] makeCurrentContext];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);

		//call display here
		[self display];
        [self myupdate];

		//swap buffers i.e. double buffering
		CGLFlushDrawable((CGLContextObj)[[self openGLContext] CGLContextObj]);

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(int)initialize
	{
		//code
		//Vertex Shader
		const GLchar* vertexShaderSourceCode =
			"#version 410 core" \
			"\n" \
			"in vec4 a_position;" \
			"in vec3 a_normal;" \
			"uniform mat4 u_modelMatrix;" \
			"uniform mat4 u_viewMatrix;" \
			"uniform mat4 u_projectionMatrix;" \
			"uniform vec3 u_ld;" \
			"uniform vec3 u_kd;" \
			"uniform vec4 u_lightPosition;" \
			"uniform int u_lightingEnabled;" \
			"out vec3 diffuse_light_color;" \
			"void main(void)" \
			"{" \
			"if (u_lightingEnabled == 1)" \
			"	{" \
			"vec4 eyeCoordinates = u_viewMatrix * u_modelMatrix * a_position;" \
			"mat3 normalMatrix = mat3(transpose(inverse(u_viewMatrix * u_modelMatrix)));" \
			"vec3 transformedNormals = normalize(normalMatrix * a_normal);" \
			"vec3 lightDirection = normalize(vec3(u_lightPosition - eyeCoordinates));" \
			"diffuse_light_color = u_ld * u_kd * max(dot(lightDirection, transformedNormals), 0.0);" \
			"	}"\
			"gl_Position = u_projectionMatrix * u_viewMatrix * u_modelMatrix * a_position;" \
			"}";

		GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
		glShaderSource(vertexShaderObject, 1, (const GLchar**)&vertexShaderSourceCode, NULL);
		glCompileShader(vertexShaderObject);

		GLint status;
		GLint infoLogLength;
		char *log = NULL;

		glGetShaderiv(vertexShaderObject, GL_COMPILE_STATUS, &status);
		if (status == GL_FALSE)
		{
			glGetShaderiv(vertexShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
			if (infoLogLength > 0)
			{
				log = (char *)malloc(infoLogLength);
				if (log != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(vertexShaderObject, infoLogLength, &written, log);
					fprintf(gpFile, "\n\nVertex Shader Compilation Log : %s\n\n", log);
					fprintf(gpFile, "\n\n");
					free(log);
					log = NULL;
					[self uninitialize];
				}
			}
		}

		//Fragment Shader
		const GLchar* fragmentShaderSourceCode =
			"#version 410 core" \
			"\n" \
			"in vec3 diffuse_light_color;" \
			"uniform int u_lightingEnabled;" \
			"out vec4 FragColor;" \
			"void main(void)" \
			"{" \
			"if (u_lightingEnabled == 1)" \
			"	{" \
			"FragColor = vec4(diffuse_light_color, 1.0);" \
			"	}" \
			"else" \
			"	{" \
			"FragColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);"
			"	}" \
			"}";

		GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
		glShaderSource(fragmentShaderObject, 1, (const GLchar**)&fragmentShaderSourceCode, NULL);
		glCompileShader(fragmentShaderObject);

		status = 0;
		infoLogLength = 0;
		log = NULL;

		glGetShaderiv(fragmentShaderObject, GL_COMPILE_STATUS, &status);
		if (status == GL_FALSE)
		{
			glGetShaderiv(fragmentShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
			if (infoLogLength > 0)
			{
				log = (char*)malloc(infoLogLength);
				if (log != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(fragmentShaderObject, infoLogLength, &written, log);
					fprintf(gpFile, "\n\nFragment Shader Compilation Log : %s", log);
					free(log);
					log = NULL;
					[self uninitialize];
				}
			}
		}

		//Shader Program object
		shaderProgramObject = glCreateProgram();
		glAttachShader(shaderProgramObject, vertexShaderObject);
		glAttachShader(shaderProgramObject, fragmentShaderObject);

		glBindAttribLocation(shaderProgramObject, SDJ_ATTRIBUTE_POSITION, "a_position");
		glBindAttribLocation(shaderProgramObject, SDJ_ATTRIBUTE_NORMAL, "a_normal");

		glLinkProgram(shaderProgramObject);


		//ERROR Checking
		status = 0;
		infoLogLength = 0;
		log = NULL;

		glGetProgramiv(shaderProgramObject, GL_LINK_STATUS, &status);
		if (status == GL_FALSE)
		{
			glGetProgramiv(shaderProgramObject, GL_INFO_LOG_LENGTH, &infoLogLength);
			if (infoLogLength > 0)
			{
				log = (char*)malloc(infoLogLength);
				if (log != NULL)
				{
					GLsizei written;
					glGetProgramInfoLog(shaderProgramObject, infoLogLength, &written, log);
					fprintf(gpFile, "\n\nShader Program Link log : %s", log);
					free(log);
					log = NULL;
					[self uninitialize];
				}
			}
		}

		//post link steps--u_modelMatrix * u_viewMatrix * u_projectionMatrix
		modelMatrixUniform = glGetUniformLocation(shaderProgramObject, "u_modelMatrix");
		viewMatrixUniform = glGetUniformLocation(shaderProgramObject, "u_viewMatrix");
		projectionMatrixUniform = glGetUniformLocation(shaderProgramObject, "u_projectionMatrix");

		ldUniform = glGetUniformLocation(shaderProgramObject, "u_ld");
		kdUniform = glGetUniformLocation(shaderProgramObject, "u_kd");
		lightPositionUniform = glGetUniformLocation(shaderProgramObject, "u_lightPosition");
		lightingEnabledUniform = glGetUniformLocation(shaderProgramObject, "u_lightingEnabled");

		//declarations of vertex data arrays
		//declarations of vertex data arrays
		const GLfloat cubePosition[] =
		{
			// top
			1.0f, 1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,
			-1.0f, 1.0f, 1.0f,
			1.0f, 1.0f, 1.0f,

			// bottom
			1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f,  1.0f,
			1.0f, -1.0f,  1.0f,

			// front
			1.0f, 1.0f, 1.0f,
			-1.0f, 1.0f, 1.0f,
			-1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,

			// back
			1.0f, 1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f,

			// right
			1.0f, 1.0f, -1.0f,
			1.0f, 1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, -1.0f,

			// left
			-1.0f, 1.0f, 1.0f,
			-1.0f, 1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f, 1.0f,

		};

		const GLfloat cubeNormals[] =
		{
			// top surface
			0.0f, 1.0f, 0.0f,  // top-right of top
			0.0f, 1.0f, 0.0f, // top-left of top
			0.0f, 1.0f, 0.0f, // bottom-left of top
			0.0f, 1.0f, 0.0f,  // bottom-right of top

			// bottom surface
			0.0f, -1.0f, 0.0f,  // top-right of bottom
			0.0f, -1.0f, 0.0f,  // top-left of bottom
			0.0f, -1.0f, 0.0f,  // bottom-left of bottom
			0.0f, -1.0f, 0.0f,   // bottom-right of bottom

			// front surface
			0.0f, 0.0f, 1.0f,  // top-right of front
			0.0f, 0.0f, 1.0f, // top-left of front
			0.0f, 0.0f, 1.0f, // bottom-left of front
			0.0f, 0.0f, 1.0f,  // bottom-right of front

			// back surface
			0.0f, 0.0f, -1.0f,  // top-right of back
			0.0f, 0.0f, -1.0f, // top-left of back
			0.0f, 0.0f, -1.0f, // bottom-left of back
			0.0f, 0.0f, -1.0f,  // bottom-right of back

			// right surface
			1.0f, 0.0f, 0.0f,  // top-right of right
			1.0f, 0.0f, 0.0f,  // top-left of right
			1.0f, 0.0f, 0.0f,  // bottom-left of right
			1.0f, 0.0f, 0.0f,

			// left surface
			-1.0f, 0.0f, 0.0f, // top-right of left
			-1.0f, 0.0f, 0.0f, // top-left of left
			-1.0f, 0.0f, 0.0f, // bottom-left of left
			-1.0f, 0.0f, 0.0f, // bottom-right of left
		};

		//vao and vbo related code
		//____Cube____
		//vertex array object
		glGenVertexArrays(1, &vao);
		glBindVertexArray(vao);

		//vertex buffer object for ___position__
		glGenBuffers(1, &vbo_position);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_position);

		glBufferData(GL_ARRAY_BUFFER, sizeof(cubePosition), cubePosition, GL_STATIC_DRAW);
		glVertexAttribPointer(SDJ_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(SDJ_ATTRIBUTE_POSITION);

		glBindBuffer(GL_ARRAY_BUFFER, 0);

		//vertex buffer object for ___color___
		glVertexAttrib3f(SDJ_ATTRIBUTE_COLOR, 1.0f, 1.0f, 1.0f);

		//normal vbo
		//vertex buffer object for ___position__
		glGenBuffers(1, &vbo_normals);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_normals);

		glBufferData(GL_ARRAY_BUFFER, sizeof(cubeNormals), cubeNormals, GL_STATIC_DRAW);
		glVertexAttribPointer(SDJ_ATTRIBUTE_NORMAL, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(SDJ_ATTRIBUTE_NORMAL);

		glBindBuffer(GL_ARRAY_BUFFER, 0);

		//unbind vao
		glBindVertexArray(0);

		glClearDepth(1.0f);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		perspectiveProjectionMatrix = mat4::identity();
		return 0;
	}

	//overriden
	-(void)reshape
	{
		//code
		[super reshape];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
		NSRect rect = [self bounds];
		int width = rect.size.width;
		int height = rect.size.height;

		//call our resize
		[self resize:width :height];

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(void)resize:(int)width :(int)height
	{
		//code
		if (height < 0)
			height = 1;
		
		glViewport(0, 0, (GLsizei)width, (GLsizei)height);

		perspectiveProjectionMatrix = vmath::perspective(
			45.0, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
	}

	-(void)display
	{
		//code
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//use shader program object
		glUseProgram(shaderProgramObject);

		//_____Pyramid_____
		//transformations
		mat4 translationMatrix = mat4::identity();
		mat4 scaleMatrix = mat4::identity();
		mat4 rotationMatrix = mat4::identity();
		mat4 modelMatrix = mat4::identity();
		mat4 viewMatrix = mat4::identity();

		translationMatrix = translate(0.0f, 0.0f, -5.0f);
		scaleMatrix = scale(0.75f, 0.75f, 0.75f);
		rotationMatrix = rotate(angleCube, 1.0f, 0.0f, 0.0f);
        rotationMatrix *= rotate(angleCube, 0.0f, 1.0f, 0.0f);
        rotationMatrix *= rotate(angleCube, 0.0f, 0.0f, 1.0f);
		modelMatrix = translationMatrix * scaleMatrix * rotationMatrix;

		glUniformMatrix4fv(modelMatrixUniform, 1, GL_FALSE, modelMatrix);
		glUniformMatrix4fv(viewMatrixUniform, 1, GL_FALSE, viewMatrix);
		glUniformMatrix4fv(projectionMatrixUniform, 1, GL_FALSE, perspectiveProjectionMatrix);

		if (bLight == true)
		{
			glUniform1i(lightingEnabledUniform, 1);
			glUniform3fv(ldUniform, 1, lightDiffuse);
			glUniform3fv(kdUniform, 1, materialDiffuse);
			glUniform4fv(lightPositionUniform, 1, lightPosition);
		}
		else
			glUniform1i(lightingEnabledUniform, 0);

		//draw
		glBindVertexArray(vao);
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        glDrawArrays(GL_TRIANGLE_FAN, 4, 4);
        glDrawArrays(GL_TRIANGLE_FAN, 8, 4);
        glDrawArrays(GL_TRIANGLE_FAN, 12, 4);
        glDrawArrays(GL_TRIANGLE_FAN, 16, 4);
        glDrawArrays(GL_TRIANGLE_FAN, 20, 4);
        glBindVertexArray(0);

		//unuse the shader program object
		glUseProgram(0);
	}

	-(void)myupdate
	{
		//code
		angleCube += 0.5f;
		if (angleCube >= 360.0f)
			angleCube -= 360.0f;
	}

	-(void)uninitialize
	{
		//code
		//deletion and uninitialization of vbo
		if (vbo_normals)
		{
			glDeleteVertexArrays(1, &vbo_normals);
			vbo_normals = 0;
		}

		if (vbo_position)
		{
			glDeleteBuffers(1, &vbo_position);
			vbo_position = 0;
		}

		if (vao)
		{
			glDeleteVertexArrays(1, &vao);
			vao = 0;
		}

		//shader uninitialization
		if (shaderProgramObject)
		{
			glUseProgram(shaderProgramObject);
			GLsizei numAttachedShaders;
			glGetProgramiv(shaderProgramObject, GL_ATTACHED_SHADERS, &numAttachedShaders);
			GLuint *shaderObjects = NULL;
			shaderObjects = (GLuint *)malloc(numAttachedShaders * sizeof(GLuint));

			//filling empty buffer with shader objects
			glGetAttachedShaders(shaderProgramObject, numAttachedShaders, &numAttachedShaders, shaderObjects);

			for (GLsizei i = 0; i < numAttachedShaders; i++)
			{
				glDetachShader(shaderProgramObject, shaderObjects[i]);
				glDeleteShader(shaderObjects[i]);
				shaderObjects[i] = 0;
			}

			free(shaderObjects);
			shaderObjects = NULL;
			glUseProgram(0);
			glDeleteProgram(shaderProgramObject);
			shaderProgramObject = 0;
		}
	}

	-(BOOL)acceptsFirstResponder
	{
		//code
		[[self window]makeFirstResponder:self];

		return YES;
	}

	-(void)keyDown:(NSEvent *)event
	{
		//code
		int key = (int)[[event characters]characterAtIndex:0];

		switch(key)
		{
		case 27:
			[self uninitialize];
			[self release];
			[NSApp terminate:self];
			break;
		case 'f':
		case 'F':
			[[self window] toggleFullScreen:self];
			if (gbFullscreen == false)
				gbFullscreen = true;
			else
				gbFullscreen = false;
			break;

		case 'L':
		case 'l':
			if (bLight == false)
				bLight = true;
			else
				bLight = false;
			break;

		default:
			break;
		}
	}

	-(void)mouseDown:(NSEvent *)event
	{
		//code

	}

	-(void)dealloc
	{
		//code
		[super dealloc];

		if (displayLink)
		{
			CVDisplayLinkStop(displayLink);
			CVDisplayLinkRelease(displayLink);
			displayLink = nil;
		}
	}
@end

//implement display link callback function
CVReturn myDisplayLinkCallback(CVDisplayLinkRef displayLink, const CVTimeStamp *currentTime, const CVTimeStamp *outputTime, CVOptionFlags flagsIn, CVOptionFlags *flagsOut, void *view)
{
	//code
	CVReturn result = [(GLView *)view getFrameForTime:outputTime];

	return result;
}
