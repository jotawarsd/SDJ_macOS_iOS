//header files
#import <foundation/foundation.h>
#import <cocoa/cocoa.h>

#import <QuartzCore/CVDisplayLink.h>

#import <OpenGL/gl3.h>
#import <OpenGL/gl3ext.h>

CVReturn myDisplayLinkCallback(CVDisplayLinkRef, const CVTimeStamp *, const CVTimeStamp *, CVOptionFlags, CVOptionFlags *, void *);

//global variable declarations
FILE *gpFile = NULL;

//interface declarations
@interface AppDelegate:NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

// @interface myView:NSView
// @end

@interface GLView:NSOpenGLView
@end

//entry point function
int main (int argc, char *argv[])
{
	//code
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];     //create autorelease pool
	NSApp = [NSApplication sharedApplication];

	//create app delegate object
	AppDelegate *appDelegate = [[AppDelegate alloc] init];

	//give the app delegate to NSApp
	[NSApp setDelegate:appDelegate];

	//start run(game) loop
	[NSApp run];

	//tell autorelease pool to release all objects created by this application
	[pool release];

	return 0;
}

//implementation of app delegate
@implementation AppDelegate 
	{
		@private
		NSWindow *window;
		GLView *view;
	}

	-(void)applicationDidFinishLaunching:(NSNotification *)notification
	{
		//code
		NSBundle *appBundle = [NSBundle mainBundle];
		NSString *appDirPath = [appBundle bundlePath];
		NSString *parentDirPath = [appDirPath stringByDeletingLastPathComponent];
		NSString *logFileNameWithPath = [NSString stringWithFormat:@"%@/Log.txt",parentDirPath];
		const char *pszLogFileNameWithPath = [logFileNameWithPath UTF8String];

		gpFile = fopen(pszLogFileNameWithPath, "w");
		if (gpFile == NULL)
			[NSApp terminate:self];
		fprintf(gpFile, "Program Started Successfully!!\n");

		NSRect rect = NSMakeRect(0.0, 0.0, 800.0, 600.0);

		window = [[NSWindow alloc]initWithContentRect:rect
			styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable
			backing:NSBackingStoreBuffered
			defer:NO];
		
		[window setTitle:@"macOS Window : SDJ"];

		//set background color
		NSColor *bkColor = [NSColor blackColor];
		[window setBackgroundColor:bkColor];

		view = [[GLView alloc]initWithFrame:rect];
		[window setContentView:view];

		[window center];		//center the window
		[window setDelegate:self];		//set window's delegate to this object
		[window makeKeyAndOrderFront:self];
	}

	-(void)applicationWillTerminate:(NSNotification *)notification
	{
		//code
		if (gpFile)
		{
			fprintf(gpFile, "Program Terminated Successfully!!\n");
			fclose(gpFile);
			gpFile = NULL;
		}
	}

	-(void)windowWillClose:(NSNotification *)notification
	{
		//code
		[NSApp terminate:self];
	}

	-(void)dealloc
	{
		//code
		if (view)
		{
			[view release];
			view = nil;
		}

		if (window)
		{
			[window release];
			window = nil;
		}

		[super dealloc];
	}
@end


//implement GLView
@implementation GLView
	{
		@private
		CVDisplayLinkRef displayLink;
	}

	-(id)initWithFrame:(NSRect)frame
	{
		//code  
		self = [super initWithFrame:frame];
		if (self)
		{
		//initialize array of OpenGL pixel format attributes
			NSOpenGLPixelFormatAttribute openGLPixelFormatAttributes[] = 
			{
				NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,
				NSOpenGLPFAScreenMask, CGDisplayIDToOpenGLDisplayMask(kCGDirectMainDisplay),
				NSOpenGLPFAColorSize, 24,
				NSOpenGLPFADepthSize, 24,
				NSOpenGLPFAAlphaSize, 8,
				NSOpenGLPFANoRecovery, 
				NSOpenGLPFAAccelerated,
				NSOpenGLPFADoubleBuffer, 
				0
			};

		//create OpenGL pixel format using above attributes
			NSOpenGLPixelFormat *glPixelFormat = [[[NSOpenGLPixelFormat alloc] initWithAttributes:openGLPixelFormatAttributes]autorelease];
			if (glPixelFormat == nil)
			{
				fprintf(gpFile, "glPixelFormat creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//create OpenGL context using above pixel format
			NSOpenGLContext *glContext = [[[NSOpenGLContext alloc] initWithFormat:glPixelFormat shareContext:nil] autorelease];
			if (glContext == nil)
			{
				fprintf(gpFile, "glContext creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//set this view's pixel format to the above pixel format
			[self setPixelFormat:glPixelFormat];
		
		//set view's OpenGL context to above context
			[self setOpenGLContext:glContext];
		}
		
		return self;
	}

	//define getFrameForTime method which will be called by my displayLinkCallback
	-(CVReturn)getFrameForTime:(const CVTimeStamp *)outputTime
	{
		//code
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

		[self drawView];

		[pool release];

		return kCVReturnSuccess;
	}

	-(void)prepareOpenGL
	{
		//code
		[super prepareOpenGL];
		
		//make the openGL context as current context
		[[self openGLContext] makeCurrentContext];

		//set double buffer swapping interval to 1
		GLint swapInterval = 1;
		[[self openGLContext] setValues:&swapInterval forParameter:NSOpenGLCPSwapInterval];

		//openGL log
		fprintf(gpFile, "\n\n-----printGLInfo-----\n\n");
		fprintf(gpFile, "OpenGL Vendor: %s\n", glGetString(GL_VENDOR));
		fprintf(gpFile, "OpenGL Renderer: %s\n", glGetString(GL_RENDERER));
		fprintf(gpFile, "OpenGL Version: %s\n", glGetString(GL_VERSION));
		fprintf(gpFile, "GLSL Version: %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

		fprintf(gpFile, "\n\n");

		//call initialize
		[self initialize];

		//create, configure, start display link
		//step 1
		CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);
		
		//step 2
		CVDisplayLinkSetOutputCallback(displayLink, &myDisplayLinkCallback, self);

		//step 3
		CGLPixelFormatObj cglPixelFormat = (CGLPixelFormatObj)[[self pixelFormat] CGLPixelFormatObj];

		//step 4
		CGLContextObj cglContext = (CGLContextObj)[[self openGLContext] CGLContextObj];

		//step 5
		CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);

		//step 6
		CVDisplayLinkStart(displayLink);
		
	}

	-(void)drawRect:(NSRect)dirtyRect
	{
		//code
		[self drawView];
	}

	-(void)drawView
	{
		//code
		[[self openGLContext] makeCurrentContext];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);

		//call display here
		[self display];

		//swap buffers i.e. double buffering
		CGLFlushDrawable((CGLContextObj)[[self openGLContext] CGLContextObj]);

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(int)initialize
	{
		//code
		glClearDepth(1.0f);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glClearColor(0.0f, 0.5f, 1.0f, 1.0f);
		return 0;
	}

	//overriden
	-(void)reshape
	{
		//code
		[super reshape];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
		NSRect rect = [self bounds];
		int width = rect.size.width;
		int height = rect.size.height;

		//call our resize
		[self resize:width :height];

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(void)resize:(int)width :(int)height
	{
		//code
		if (height < 0)
			height = 1;
		
		glViewport(0, 0, (GLsizei)width, (GLsizei)height);
	}

	-(void)display
	{
		//code
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}
	//display->drawView->getFrameForTime->displayLinkCallback->quartzCoreDriver
	//quartz core driver calls displayLinkCallback.
	//displayLinkCallback calls getFrameForTime
	//getFrameForTime calls drawView
	//drawView calls display()
	//drawRect is used for the main thread of the program.
	//drawView is used by the new thread created for opengl

	-(void)myupdate
	{
		//code
		/*NSOpenGLView has its own update function.
		Hence we have named this function as myupdate*/

	}

	-(void)uninitialize
	{
		//code

	}

	-(BOOL)acceptsFirstResponder
	{
		//code
		[[self window]makeFirstResponder:self];

		return YES;
	}

	-(void)keyDown:(NSEvent *)event
	{
		//code
		int key = (int)[[event characters]characterAtIndex:0];

		switch(key)
		{
		case 27:
			[self uninitialize];
			[self release];
			[NSApp terminate:self];
			break;
		case 'f':
		case 'F':
			[[self window] toggleFullScreen:self];
			break;
		default:
			break;
		}
	}

	-(void)mouseDown:(NSEvent *)event
	{
		//code

	}

	-(void)dealloc
	{
		//code
		[super dealloc];

		if (displayLink)
		{
			CVDisplayLinkStop(displayLink);
			CVDisplayLinkRelease(displayLink);
			displayLink = nil;
		}
	}
@end

//implement display link callback function
CVReturn myDisplayLinkCallback(CVDisplayLinkRef displayLink, const CVTimeStamp *currentTime, const CVTimeStamp *outputTime, CVOptionFlags flagsIn, CVOptionFlags *flagsOut, void *view)
{
	//code
	CVReturn result = [(GLView *)view getFrameForTime:outputTime];

	return result;
}
