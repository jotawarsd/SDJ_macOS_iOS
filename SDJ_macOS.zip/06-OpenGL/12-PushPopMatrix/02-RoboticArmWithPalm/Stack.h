#pragma once
#include "vmath.h"
#include <stdio.h>
#include <stdlib.h>
using namespace vmath;

struct Node
{
	mat4 matrix;
	struct Node *next;
};

Node *top = NULL;

void pushMatrix(mat4 data)
{
	Node *temp = (struct Node *)malloc(sizeof(struct Node));
	temp->matrix = data;
	if (top == NULL)
		temp->next = NULL;
	else
		temp->next = top;
	top = temp;
}

mat4 popMatrix()
{
	struct Node *temp = top;
	mat4 tempData = temp->matrix;
	top = temp->next;
	free(temp);
	temp = NULL;

	return tempData;
}
