#pragma once
#include "vmath.h"
#include <stdio.h>
#include <stdlib.h>
using namespace vmath;

struct Node
{
	mat4 matrix;
	struct Node *next;
};

Node *top = NULL;

void push(mat4 data)
{
	Node *temp = (struct Node *)malloc(sizeof(struct Node));
	temp->matrix = data;
	if (top == NULL)
		temp->next = NULL;
	else
		temp->next = top;
	top = temp;
}

mat4 pop()
{
	struct Node *temp = top;
	mat4 tempData = temp->matrix;
	top = temp->next;
	free(temp);
	temp = NULL;

	return tempData;
}

mat4 getTop(void)
{
	//code
	if (top == NULL)
		return top->matrix;
	else
		return 0;
}
