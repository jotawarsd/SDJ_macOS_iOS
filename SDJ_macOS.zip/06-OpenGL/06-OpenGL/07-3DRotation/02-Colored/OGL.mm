//header files
#import <foundation/foundation.h>
#import <cocoa/cocoa.h>

#import <QuartzCore/CVDisplayLink.h>

#import <OpenGL/gl3.h>
#import <OpenGL/gl3ext.h>

#import "vmath.h"
using namespace vmath;

CVReturn myDisplayLinkCallback(CVDisplayLinkRef, const CVTimeStamp *, const CVTimeStamp *, CVOptionFlags, CVOptionFlags *, void *);

//global variable declarations
FILE *gpFile = NULL;

//interface declarations
@interface AppDelegate:NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

//Programmable pipeline related global variables
GLuint shaderProgramObject;

enum
{
	SDJ_ATTRIBUTE_POSITION = 0,
	SDJ_ATTRIBUTE_COLOR,
	SDJ_ATTRIBUTE_NORMAL,
	SDJ_ATTRIBUTE_TEXTURE0
};

GLuint vao_pyramid;
GLuint vbo_pyramid_position;
GLuint vbo_pyramid_color;

GLuint vao_cube;
GLuint vbo_cube_position;
GLuint vbo_cube_color;

mat4 perspectiveProjectionMatrix;

bool gbFullscreen = false;

GLfloat anglePyramid = 0.0f;
GLfloat angleCube = 0.0f;

@interface GLView:NSOpenGLView
@end

//entry point function
int main (int argc, char *argv[])
{
	//code
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];     //create autorelease pool
	NSApp = [NSApplication sharedApplication];

	//create app delegate object
	AppDelegate *appDelegate = [[AppDelegate alloc] init];

	//give the app delegate to NSApp
	[NSApp setDelegate:appDelegate];

	//start run(game) loop
	[NSApp run];

	//tell autorelease pool to release all objects created by this application
	[pool release];

	return 0;
}

//implementation of app delegate
@implementation AppDelegate 
	{
		@private
		NSWindow *window;
		GLView *view;
	}

	-(void)applicationDidFinishLaunching:(NSNotification *)notification
	{
		//code
		NSBundle *appBundle = [NSBundle mainBundle];
		NSString *appDirPath = [appBundle bundlePath];
		NSString *parentDirPath = [appDirPath stringByDeletingLastPathComponent];
		NSString *logFileNameWithPath = [NSString stringWithFormat:@"%@/Log.txt",parentDirPath];
		const char *pszLogFileNameWithPath = [logFileNameWithPath UTF8String];

		gpFile = fopen(pszLogFileNameWithPath, "w");
		if (gpFile == NULL)
			[NSApp terminate:self];
		fprintf(gpFile, "Program Started Successfully!!\n");

		NSRect rect = NSMakeRect(0.0, 0.0, 800.0, 600.0);

		window = [[NSWindow alloc]initWithContentRect:rect
			styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable
			backing:NSBackingStoreBuffered
			defer:NO];
		
		[window setTitle:@"macOS Window : SDJ"];

		//set background color
		NSColor *bkColor = [NSColor blackColor];
		[window setBackgroundColor:bkColor];

		view = [[GLView alloc]initWithFrame:rect];
		[window setContentView:view];

		[window center];		//center the window
		[window setDelegate:self];		//set window's delegate to this object
		[window makeKeyAndOrderFront:self];
	}

	-(void)applicationWillTerminate:(NSNotification *)notification
	{
		//code
		if (gpFile)
		{
			fprintf(gpFile, "Program Terminated Successfully!!\n");
			fclose(gpFile);
			gpFile = NULL;
		}
	}

	-(void)windowWillClose:(NSNotification *)notification
	{
		//code
		[NSApp terminate:self];
	}

	-(void)dealloc
	{
		//code
		if (view)
		{
			[view release];
			view = nil;
		}

		if (window)
		{
			[window release];
			window = nil;
		}

		[super dealloc];
	}
@end


//implement GLView
@implementation GLView
	{
		@private
		CVDisplayLinkRef displayLink;
	}

	-(id)initWithFrame:(NSRect)frame
	{
		//code  
		self = [super initWithFrame:frame];
		if (self)
		{
		//initialize array of OpenGL pixel format attributes
			NSOpenGLPixelFormatAttribute openGLPixelFormatAttributes[] = 
			{
				NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,
				NSOpenGLPFAScreenMask, CGDisplayIDToOpenGLDisplayMask(kCGDirectMainDisplay),
				NSOpenGLPFAColorSize, 24,
				NSOpenGLPFADepthSize, 24,
				NSOpenGLPFAAlphaSize, 8,
				NSOpenGLPFANoRecovery, 
				NSOpenGLPFAAccelerated,
				NSOpenGLPFADoubleBuffer, 
				0
			};

		//create OpenGL pixel format using above attributes
			NSOpenGLPixelFormat *glPixelFormat = [[[NSOpenGLPixelFormat alloc] initWithAttributes:openGLPixelFormatAttributes]autorelease];
			if (glPixelFormat == nil)
			{
				fprintf(gpFile, "glPixelFormat creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//create OpenGL context using above pixel format
			NSOpenGLContext *glContext = [[[NSOpenGLContext alloc] initWithFormat:glPixelFormat shareContext:nil] autorelease];
			if (glContext == nil)
			{
				fprintf(gpFile, "glContext creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//set this view's pixel format to the above pixel format
			[self setPixelFormat:glPixelFormat];
		
		//set view's OpenGL context to above context
			[self setOpenGLContext:glContext];
		}
		
		return self;
	}

	//define getFrameForTime method which will be called by my displayLinkCallback
	-(CVReturn)getFrameForTime:(const CVTimeStamp *)outputTime
	{
		//code
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

		[self drawView];

		[pool release];

		return kCVReturnSuccess;
	}

	-(void)prepareOpenGL
	{
		//code
		[super prepareOpenGL];
		
		//make the openGL context as current context
		[[self openGLContext] makeCurrentContext];

		//set double buffer swapping interval to 1
		GLint swapInterval = 1;
		[[self openGLContext] setValues:&swapInterval forParameter:NSOpenGLCPSwapInterval];

		//openGL log
		fprintf(gpFile, "\n\n-----printGLInfo-----\n\n");
		fprintf(gpFile, "OpenGL Vendor: %s\n", glGetString(GL_VENDOR));
		fprintf(gpFile, "OpenGL Renderer: %s\n", glGetString(GL_RENDERER));
		fprintf(gpFile, "OpenGL Version: %s\n", glGetString(GL_VERSION));
		fprintf(gpFile, "GLSL Version: %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

		fprintf(gpFile, "\n\n");

		//call initialize
		[self initialize];

		//create, configure, start display link
		//step 1
		CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);
		
		//step 2
		CVDisplayLinkSetOutputCallback(displayLink, &myDisplayLinkCallback, self);

		//step 3
		CGLPixelFormatObj cglPixelFormat = (CGLPixelFormatObj)[[self pixelFormat] CGLPixelFormatObj];

		//step 4
		CGLContextObj cglContext = (CGLContextObj)[[self openGLContext] CGLContextObj];

		//step 5
		CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);

		//step 6
		CVDisplayLinkStart(displayLink);
		
	}

	-(void)drawRect:(NSRect)dirtyRect
	{
		//code
		[self drawView];
	}

	-(void)drawView
	{
		//code
		[[self openGLContext] makeCurrentContext];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);

		//call display here
		[self display];

		//swap buffers i.e. double buffering
		CGLFlushDrawable((CGLContextObj)[[self openGLContext] CGLContextObj]);

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(int)initialize
	{
		//code
		//Vertex Shader
		const GLchar* vertexShaderSourceCode =
			"#version 410 core" \
			"\n" \
			"in vec4 a_position;" \
			"in vec4 a_color;" \
			"uniform mat4 u_mvpMatrix;" \
			"out vec4 a_color_out;" \
			"void main(void)" \
			"{" \
			"gl_Position = u_mvpMatrix * a_position;" \
			"a_color_out = a_color;" \
			"}";

		GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
		glShaderSource(vertexShaderObject, 1, (const GLchar**)&vertexShaderSourceCode, NULL);
		glCompileShader(vertexShaderObject);

		GLint status;
		GLint infoLogLength;
		char *log = NULL;

		glGetShaderiv(vertexShaderObject, GL_COMPILE_STATUS, &status);
		if (status == GL_FALSE)
		{
			glGetShaderiv(vertexShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
			if (infoLogLength > 0)
			{
				log = (char *)malloc(infoLogLength);
				if (log != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(vertexShaderObject, infoLogLength, &written, log);
					fprintf(gpFile, "\n\nVertex Shader Compilation Log : %s\n\n", log);
					free(log);
					log = NULL;
					uninitialize();
				}
			}
		}

		//Fragment Shader
		const GLchar* fragmentShaderSourceCode = 
			"#version 410 core" \
			"\n" \
			"in vec4 a_color_out;" \
			"out vec4 FragColor;" \
			"void main(void)" \
			"{" \
			"FragColor = a_color_out;" \
			"}";

		GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
		glShaderSource(fragmentShaderObject, 1, (const GLchar**)&fragmentShaderSourceCode, NULL);
		glCompileShader(fragmentShaderObject);

		status = 0;
		infoLogLength = 0;
		log = NULL;

		glGetShaderiv(fragmentShaderObject, GL_COMPILE_STATUS, &status);
		if (status == GL_FALSE)
		{
			glGetShaderiv(fragmentShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
			if (infoLogLength > 0)
			{
				log = (char*)malloc(infoLogLength);
				if (log != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(fragmentShaderObject, infoLogLength, &written, log);
					fprintf(gpFile, "\n\nFragment Shader Compilation Log : %s", log);
					free(log);
					log = NULL;
					uninitialize();
				}
			}
		}

		//Shader Program object
		shaderProgramObject = glCreateProgram();
		glAttachShader(shaderProgramObject, vertexShaderObject);
		glAttachShader(shaderProgramObject, fragmentShaderObject);
		
		glBindAttribLocation(shaderProgramObject, SDJ_ATTRIBUTE_POSITION, "a_position");
		glBindAttribLocation(shaderProgramObject, SDJ_ATTRIBUTE_COLOR, "a_color");

		glLinkProgram(shaderProgramObject);


		//ERROR Checking
		status = 0;
		infoLogLength = 0;
		log = NULL;

		glGetProgramiv(shaderProgramObject, GL_LINK_STATUS, &status);
		if (status == GL_FALSE)
		{
			glGetProgramiv(shaderProgramObject, GL_INFO_LOG_LENGTH, &infoLogLength);
			if (infoLogLength > 0)
			{
				log = (char*)malloc(infoLogLength);
				if (log != NULL)
				{
					GLsizei written;
					glGetProgramInfoLog(shaderProgramObject, infoLogLength, &written, log);
					fprintf(gpFile, "\n\nShader Program Link log : %s", log);
					free(log);
					log = NULL;
					uninitialize();
				}
			}
		}
		
		//post link steps
		mvpMatrixUniform = glGetUniformLocation(shaderProgramObject, "u_mvpMatrix");

		//declarations of vertex data arrays
		const GLfloat pyramidPosition[] =
		{
			// front
			0.0f, 1.0f, 0.0f,
			-1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,

			// right
			0.0f, 1.0f, 0.0f,
			1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, -1.0f,

			// back
			0.0f, 1.0f, 0.0f,
			1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,

			// left
			0.0f, 1.0f, 0.0f,
			-1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f, 1.0f

		};

		const GLfloat pyramidColor[] =
		{
			1.0f, 0.0f, 0.0f,
			0.0f, 1.0f, 0.0f,
			0.0f, 0.0f, 1.0f,

			1.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 1.0f,
			0.0f, 1.0f, 0.0f,

			1.0f, 0.0f, 0.0f,
			0.0f, 1.0f, 0.0f,
			0.0f, 0.0f, 1.0f,

			1.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 1.0f,
			0.0f, 1.0f, 0.0f

		};

		const GLfloat cubePosition[] =
		{
			// top
			1.0f, 1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,
			-1.0f, 1.0f, 1.0f,
			1.0f, 1.0f, 1.0f,

			// bottom
			1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f,  1.0f,
			1.0f, -1.0f,  1.0f,

			// front
			1.0f, 1.0f, 1.0f,
			-1.0f, 1.0f, 1.0f,
			-1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,

			// back
			1.0f, 1.0f, -1.0f,
			-1.0f, 1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f,

			// right
			1.0f, 1.0f, -1.0f,
			1.0f, 1.0f, 1.0f,
			1.0f, -1.0f, 1.0f,
			1.0f, -1.0f, -1.0f,

			// left
			-1.0f, 1.0f, 1.0f,
			-1.0f, 1.0f, -1.0f,
			-1.0f, -1.0f, -1.0f,
			-1.0f, -1.0f, 1.0f,

		};
		
		const GLfloat cubeColor[] =
		{
			0.0f, 1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,

			1.0f, 0.5f, 0.0f,
			1.0f, 0.5f, 0.0f,
			1.0f, 0.5f, 0.0f,
			1.0f, 0.5f, 0.0f,

			1.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,
			1.0f, 0.0f, 0.0f,

			1.0f, 1.0f, 0.0f,
			1.0f, 1.0f, 0.0f,
			1.0f, 1.0f, 0.0f,
			1.0f, 1.0f, 0.0f,

			0.0f, 0.0f, 1.0f,
			0.0f, 0.0f, 1.0f,
			0.0f, 0.0f, 1.0f,
			0.0f, 0.0f, 1.0f,

			1.0f, 0.0f, 1.0f,
			1.0f, 0.0f, 1.0f,
			1.0f, 0.0f, 1.0f,
			1.0f, 0.0f, 1.0f
		};

		//vao and vbo related code
		//____Pyramid____
		//vertex array object
		glGenVertexArrays(1, &vao_pyramid);
		glBindVertexArray(vao_pyramid);

		//vertex buffer object for ___position___
		glGenBuffers(1, &vbo_pyramid_position);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_pyramid_position);

		glBufferData(GL_ARRAY_BUFFER, sizeof(pyramidPosition), pyramidPosition, GL_STATIC_DRAW);
		glVertexAttribPointer(SDJ_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(SDJ_ATTRIBUTE_POSITION);

		glBindBuffer(GL_ARRAY_BUFFER, 0);

		//vertex buffer object for ___color___
		glGenBuffers(1, &vbo_pyramid_color);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_pyramid_color);

		glBufferData(GL_ARRAY_BUFFER, sizeof(pyramidColor), pyramidColor, GL_STATIC_DRAW);
		glVertexAttribPointer(SDJ_ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(SDJ_ATTRIBUTE_COLOR);

		glBindBuffer(GL_ARRAY_BUFFER, 0);

		//unbind __vao__
		glBindVertexArray(0);

		//____Cube____
		//vertex array object
		glGenVertexArrays(1, &vao_cube);
		glBindVertexArray(vao_cube);

		//vertex buffer object for ___position__
		glGenBuffers(1, &vbo_cube_position);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_cube_position);

		glBufferData(GL_ARRAY_BUFFER, sizeof(cubePosition), cubePosition, GL_STATIC_DRAW);
		glVertexAttribPointer(SDJ_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(SDJ_ATTRIBUTE_POSITION);

		glBindBuffer(GL_ARRAY_BUFFER, 0);

		//vertex buffer object for ___color___
		glGenBuffers(1, &vbo_cube_color);
		glBindBuffer(GL_ARRAY_BUFFER, vbo_cube_color);

		glBufferData(GL_ARRAY_BUFFER, sizeof(cubeColor), cubeColor, GL_STATIC_DRAW);
		glVertexAttribPointer(SDJ_ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(SDJ_ATTRIBUTE_COLOR);

		glBindBuffer(GL_ARRAY_BUFFER, 0);

		//unbind vao
		glBindVertexArray(0);

		glClearDepth(1.0f);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		perspectiveProjectionMatrix = mat4::identity();
		return 0;
	}

	//overriden
	-(void)reshape
	{
		//code
		[super reshape];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
		NSRect rect = [self bounds];
		int width = rect.size.width;
		int height = rect.size.height;

		//call our resize
		[self resize:width :height];

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(void)resize:(int)width :(int)height
	{
		//code
		if (height < 0)
			height = 1;
		
		glViewport(0, 0, (GLsizei)width, (GLsizei)height);

		perspectiveProjectionMatrix = vmath::perspective(
			45.0, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
	}

	-(void)display
	{
		//code
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//use shader program object
		glUseProgram(shaderProgramObject);

		//transformations
		mat4 translationMatrix = mat4::identity();
		mat4 scaleMatrix = mat4::identity();
		mat4 rotationMatrix = mat4::identity();
		mat4 rotationMatrix_x = mat4::identity();
		mat4 rotationMatrix_y = mat4::identity();
		mat4 rotationMatrix_z = mat4::identity();
		mat4 modelViewMatrix = mat4::identity();
		mat4 modelViewProjectionMatrix = mat4::identity();
		
		translationMatrix = translate(-1.5f, 0.0f, -6.0f);
		scaleMatrix = scale(1.0f, 1.0f, 1.0f);
		rotationMatrix = rotate(anglePyramid, 0.0f, 1.0f, 0.0f);
		modelViewMatrix = translationMatrix * scaleMatrix * rotationMatrix;		//operator overloading in mat4 is used for multiplication. *order of multiplication is very important*
		modelViewProjectionMatrix = perspectiveProjectionMatrix * modelViewMatrix;
		glUniformMatrix4fv(mvpMatrixUniform, 1, GL_FALSE, modelViewProjectionMatrix);

		//bind vao
		glBindVertexArray(vao_pyramid);

		//Draw
		glDrawArrays(GL_TRIANGLES, 0, 12);

		//unbind vao
		glBindVertexArray(0);

		//_____cube_____
		translationMatrix = mat4::identity();
		scaleMatrix = mat4::identity();
		rotationMatrix = mat4::identity();
		rotationMatrix_x = mat4::identity();
		rotationMatrix_y = mat4::identity();
		rotationMatrix_z = mat4::identity();
		modelViewMatrix = mat4::identity();
		modelViewProjectionMatrix = mat4::identity();

		translationMatrix = translate(1.5f, 0.0f, -6.0f);
		scaleMatrix = scale(0.75f, 0.75f, 0.75f);
		rotationMatrix_x = rotate(angleCube, 1.0f, 0.0f, 0.0f);
		rotationMatrix_y = rotate(angleCube, 0.0f, 1.0f, 0.0f);
		rotationMatrix_z = rotate(angleCube, 0.0f, 0.0f, 1.0f);
		rotationMatrix = rotationMatrix_x * rotationMatrix_y * rotationMatrix_z;
		modelViewMatrix = translationMatrix * scaleMatrix * rotationMatrix;
		modelViewProjectionMatrix = perspectiveProjectionMatrix * modelViewMatrix;
		glUniformMatrix4fv(mvpMatrixUniform, 1, GL_FALSE, modelViewProjectionMatrix);

		//bind vao
		glBindVertexArray(vao_cube);

		//Draw
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
		glDrawArrays(GL_TRIANGLE_FAN, 4, 4);
		glDrawArrays(GL_TRIANGLE_FAN, 8, 4);
		glDrawArrays(GL_TRIANGLE_FAN, 12, 4);
		glDrawArrays(GL_TRIANGLE_FAN, 16, 4);
		glDrawArrays(GL_TRIANGLE_FAN, 20, 4);

		//unbind vao
		glBindVertexArray(0);

		//unuse the shader program object
		glUseProgram(0);
	}

	-(void)myupdate
	{
		//code
		anglePyramid += 0.5f;
		if (anglePyramid >= 360.0f)
			anglePyramid -= 360.0f;

		angleCube += 0.5f;
		if (angleCube >= 360.0f)
			angleCube -= 360.0f;

	}

	-(void)uninitialize
	{
		//code
		//deletion and uninitialization of vbo
		if (vbo_cube_color)
		{
			glDeleteBuffers(1, &vbo_cube_color);
			vbo_cube_color = 0;
		}

		if (vbo_cube_position)
		{
			glDeleteBuffers(1, &vbo_cube_position);
			vbo_cube_position = 0;
		}

		if (vao_cube)
		{
			glDeleteVertexArrays(1, &vao_cube);
			vao_cube = 0;
		}

		if (vbo_pyramid_color)
		{
			glDeleteBuffers(1, &vbo_pyramid_color);
			vbo_pyramid_color = 0;
		}

		//deletion and uninitialization of vbo
		if (vbo_pyramid_position)
		{
			glDeleteBuffers(1, &vbo_pyramid_position);
			vbo_pyramid_position = 0;
		}

		//deletion and uninitialization of vao
		if (vao_pyramid)
		{
			glDeleteVertexArrays(1, &vao_pyramid);
			vao_pyramid = 0;
		}
		
		//shader uninitialization
		if (shaderProgramObject)
		{
			glUseProgram(shaderProgramObject);
			GLsizei numAttachedShaders;
			glGetProgramiv(shaderProgramObject, GL_ATTACHED_SHADERS, &numAttachedShaders);
			GLuint *shaderObjects = NULL;
			shaderObjects = (GLuint *)malloc(numAttachedShaders * sizeof(GLuint));

			//filling empty buffer with shader objects
			glGetAttachedShaders(shaderProgramObject, numAttachedShaders, &numAttachedShaders, shaderObjects);

			for (GLsizei i = 0; i < numAttachedShaders; i++)
			{
				glDetachShader(shaderProgramObject, shaderObjects[i]);
				glDeleteShader(shaderObjects[i]);
				shaderObjects[i] = 0;
			}

			free(shaderObjects);
			shaderObjects = NULL;
			glUseProgram(0);
			glDeleteProgram(shaderProgramObject);
			shaderProgramObject = 0;
		}
	}

	-(BOOL)acceptsFirstResponder
	{
		//code
		[[self window]makeFirstResponder:self];

		return YES;
	}

	-(void)keyDown:(NSEvent *)event
	{
		//code
		int key = (int)[[event characters]characterAtIndex:0];

		switch(key)
		{
		case 27:
			[self uninitialize];
			[self release];
			[NSApp terminate:self];
			break;
		case 'f':
		case 'F':
			[[self window] toggleFullScreen:self];
			if (gbFullscreen == false)
				gbFullscreen = true;
			else
				gbFullscreen = false;
			break;
		default:
			break;
		}
	}

	-(void)mouseDown:(NSEvent *)event
	{
		//code

	}

	-(void)dealloc
	{
		//code
		[super dealloc];

		if (displayLink)
		{
			CVDisplayLinkStop(displayLink);
			CVDisplayLinkRelease(displayLink);
			displayLink = nil;
		}
	}
@end

//implement display link callback function
CVReturn myDisplayLinkCallback(CVDisplayLinkRef displayLink, const CVTimeStamp *currentTime, const CVTimeStamp *outputTime, CVOptionFlags flagsIn, CVOptionFlags *flagsOut, void *view)
{
	//code
	CVReturn result = [(GLView *)view getFrameForTime:outputTime];

	return result;
}
