//header files
#import <foundation/foundation.h>
#import <cocoa/cocoa.h>

#import <QuartzCore/CVDisplayLink.h>

#import <OpenGL/gl3.h>
#import <OpenGL/gl3ext.h>

#import "vmath.h"
using namespace vmath;

CVReturn myDisplayLinkCallback(CVDisplayLinkRef, const CVTimeStamp *, const CVTimeStamp *, CVOptionFlags, CVOptionFlags *, void *);

//global variable declarations
FILE *gpFile = NULL;

//interface declarations
@interface AppDelegate:NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

//Programmable pipeline related global variables
GLuint shaderProgramObjectPerVertex;
GLuint shaderProgramObjectPerFragment;

enum
{
	SDJ_ATTRIBUTE_POSITION = 0,
	SDJ_ATTRIBUTE_COLOR,
	SDJ_ATTRIBUTE_NORMAL,
	SDJ_ATTRIBUTE_TEXTURE0
};

GLuint vao;
GLuint vbo_position;
GLuint vbo_normals;

//Per Vertex Uniforms
GLuint modelMatrixPvUniform;
GLuint viewMatrixPvUniform;
GLuint projectionMatrixPvUniform;

GLuint laPvUniform[3];
GLuint ldPvUniform[3];
GLuint lsPvUniform[3];
GLuint lightPositionPvUniform[3];

GLuint kaPvUniform;
GLuint kdPvUniform;
GLuint ksPvUniform;
GLuint materialShininessPvUniform;

GLuint lightingEnabledPvUniform;

//Per Fragment Uniforms
GLuint modelMatrixPfUniform;
GLuint viewMatrixPfUniform;
GLuint projectionMatrixPfUniform;

GLuint laPfUniform[3];
GLuint ldPfUniform[3];
GLuint lsPfUniform[3];
GLuint lightPositionPfUniform[3];

GLuint kaPfUniform;
GLuint kdPfUniform;
GLuint ksPfUniform;
GLuint materialShininessPfUniform;

GLuint lightingEnabledPfUniform;

mat4 perspectiveProjectionMatrix;

//light array definitions
struct Light
{
	vec4 lightAmbient;
	vec4 lightDiffuse;
	vec4 lightSpecular;
	vec4 lightPosition;
};

Light lights[3];

GLfloat materialAmbient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat materialDiffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat materialSpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat materialShininess = 50.0f;

bool bLight = false;
bool bPerVertex = false;
bool bPerFragment = false;
bool gbFullscreen = false;
bool bToggleRotate = false;
float angleSphere = 0.0f;

//sphere variables
GLuint stacks = 30;
GLuint slices = 30;
GLfloat height = 2.0f;
GLfloat radius = 2.0f;
GLuint indexCount = 0;
GLuint vertexCount = 0;

@interface GLView:NSOpenGLView
@end

//entry point function
int main (int argc, char *argv[])
{
	//code
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];     //create autorelease pool
	NSApp = [NSApplication sharedApplication];

	//create app delegate object
	AppDelegate *appDelegate = [[AppDelegate alloc] init];

	//give the app delegate to NSApp
	[NSApp setDelegate:appDelegate];

	//start run(game) loop
	[NSApp run];

	//tell autorelease pool to release all objects created by this application
	[pool release];

	return 0;
}

//implementation of app delegate
@implementation AppDelegate 
	{
		@private
		NSWindow *window;
		GLView *view;
	}

	-(void)applicationDidFinishLaunching:(NSNotification *)notification
	{
		//code
		NSBundle *appBundle = [NSBundle mainBundle];
		NSString *appDirPath = [appBundle bundlePath];
		NSString *parentDirPath = [appDirPath stringByDeletingLastPathComponent];
		NSString *logFileNameWithPath = [NSString stringWithFormat:@"%@/Log.txt",parentDirPath];
		const char *pszLogFileNameWithPath = [logFileNameWithPath UTF8String];

		gpFile = fopen(pszLogFileNameWithPath, "w");
		if (gpFile == NULL)
			[NSApp terminate:self];
		fprintf(gpFile, "Program Started Successfully!!\n");

		NSRect rect = NSMakeRect(0.0, 0.0, 800.0, 600.0);

		window = [[NSWindow alloc]initWithContentRect:rect
			styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable
			backing:NSBackingStoreBuffered
			defer:NO];
		
		[window setTitle:@"macOS Window : SDJ"];

		//set background color
		NSColor *bkColor = [NSColor blackColor];
		[window setBackgroundColor:bkColor];

		view = [[GLView alloc]initWithFrame:rect];
		[window setContentView:view];

		[window center];		//center the window
		[window setDelegate:self];		//set window's delegate to this object
		[window makeKeyAndOrderFront:self];
	}

	-(void)applicationWillTerminate:(NSNotification *)notification
	{
		//code
		if (gpFile)
		{
			fprintf(gpFile, "Program Terminated Successfully!!\n");
			fclose(gpFile);
			gpFile = NULL;
		}
	}

	-(void)windowWillClose:(NSNotification *)notification
	{
		//code
		[NSApp terminate:self];
	}

	-(void)dealloc
	{
		//code
		if (view)
		{
			[view release];
			view = nil;
		}

		if (window)
		{
			[window release];
			window = nil;
		}

		[super dealloc];
	}
@end


//implement GLView
@implementation GLView
	{
		@private
		CVDisplayLinkRef displayLink;
	}

	-(id)initWithFrame:(NSRect)frame
	{
		//code  
		self = [super initWithFrame:frame];
		if (self)
		{
		//initialize array of OpenGL pixel format attributes
			NSOpenGLPixelFormatAttribute openGLPixelFormatAttributes[] = 
			{
				NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion4_1Core,
				NSOpenGLPFAScreenMask, CGDisplayIDToOpenGLDisplayMask(kCGDirectMainDisplay),
				NSOpenGLPFAColorSize, 24,
				NSOpenGLPFADepthSize, 24,
				NSOpenGLPFAAlphaSize, 8,
				NSOpenGLPFANoRecovery, 
				NSOpenGLPFAAccelerated,
				NSOpenGLPFADoubleBuffer, 
				0
			};

		//create OpenGL pixel format using above attributes
			NSOpenGLPixelFormat *glPixelFormat = [[[NSOpenGLPixelFormat alloc] initWithAttributes:openGLPixelFormatAttributes]autorelease];
			if (glPixelFormat == nil)
			{
				fprintf(gpFile, "glPixelFormat creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//create OpenGL context using above pixel format
			NSOpenGLContext *glContext = [[[NSOpenGLContext alloc] initWithFormat:glPixelFormat shareContext:nil] autorelease];
			if (glContext == nil)
			{
				fprintf(gpFile, "glContext creation failed!!\n");
				[self uninitialize];
				[self release];
				[NSApp terminate:self];
			}

		//set this view's pixel format to the above pixel format
			[self setPixelFormat:glPixelFormat];
		
		//set view's OpenGL context to above context
			[self setOpenGLContext:glContext];
		}
		
		return self;
	}

	//define getFrameForTime method which will be called by my displayLinkCallback
	-(CVReturn)getFrameForTime:(const CVTimeStamp *)outputTime
	{
		//code
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

		[self drawView];

		[pool release];

		return kCVReturnSuccess;
	}

	-(void)prepareOpenGL
	{
		//code
		[super prepareOpenGL];
		
		//make the openGL context as current context
		[[self openGLContext] makeCurrentContext];

		//set double buffer swapping interval to 1
		GLint swapInterval = 1;
		[[self openGLContext] setValues:&swapInterval forParameter:NSOpenGLCPSwapInterval];

		//openGL log
		fprintf(gpFile, "\n\n-----printGLInfo-----\n\n");
		fprintf(gpFile, "OpenGL Vendor: %s\n", glGetString(GL_VENDOR));
		fprintf(gpFile, "OpenGL Renderer: %s\n", glGetString(GL_RENDERER));
		fprintf(gpFile, "OpenGL Version: %s\n", glGetString(GL_VERSION));
		fprintf(gpFile, "GLSL Version: %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

		fprintf(gpFile, "\n\n");

		//call initialize
		[self initialize];

		//create, configure, start display link
		//step 1
		CVDisplayLinkCreateWithActiveCGDisplays(&displayLink);
		
		//step 2
		CVDisplayLinkSetOutputCallback(displayLink, &myDisplayLinkCallback, self);

		//step 3
		CGLPixelFormatObj cglPixelFormat = (CGLPixelFormatObj)[[self pixelFormat] CGLPixelFormatObj];

		//step 4
		CGLContextObj cglContext = (CGLContextObj)[[self openGLContext] CGLContextObj];

		//step 5
		CVDisplayLinkSetCurrentCGDisplayFromOpenGLContext(displayLink, cglContext, cglPixelFormat);

		//step 6
		CVDisplayLinkStart(displayLink);
		
	}

	-(void)drawRect:(NSRect)dirtyRect
	{
		//code
		[self drawView];
	}

	-(void)drawView
	{
		//code
		[[self openGLContext] makeCurrentContext];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);

		//call display here
		[self display];

		//swap buffers i.e. double buffering
		CGLFlushDrawable((CGLContextObj)[[self openGLContext] CGLContextObj]);

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(int)initialize
	{
		//code
		//Vertex Shader
		const GLchar* vertexShaderPerVertexSourceCode =
			"#version 410 core" \
			"\n" \
			"in vec4 a_position;" \
			"in vec3 a_normal;" \
			"uniform mat4 u_modelMatrix;" \
			"uniform mat4 u_viewMatrix;" \
			"uniform mat4 u_projectionMatrix;" \
			"uniform vec3 u_la[3];" \
			"uniform vec3 u_ld[3];" \
			"uniform vec3 u_ls[3];" \
			"uniform vec4 u_lightPosition[3];" \
			"uniform vec3 u_ka;" \
			"uniform vec3 u_kd;" \
			"uniform vec3 u_ks;" \
			"uniform float u_materialShininess;" \
			"uniform int u_lightingEnabled;" \
			"out vec3 phong_ads_light;" \
			"void main(void)" \
			"{" \
			"if (u_lightingEnabled == 1)" \
			"	{" \
			"vec3 lightDirection[3];" \
			"vec3 ambient[3];" \
			"vec3 diffuse[3];" \
			"vec3 specular[3];" \
			"vec3 reflectionVector[3];" \
			"vec4 eyeCoordinates = u_viewMatrix * u_modelMatrix * a_position;" \
			"mat3 normalMatrix = mat3(u_viewMatrix * u_modelMatrix);" \
			"vec3 transformedNormals = normalize(normalMatrix * a_normal);" \
			"vec3 viewerVector = normalize(-eyeCoordinates.xyz);" \
			"for (int i = 0; i < 3; i++)" \
			"		{" \
			"ambient[i] = u_la[i] * u_ka;" \
			"lightDirection[i] = normalize(vec3(u_lightPosition[i]) - eyeCoordinates.xyz);" \
			"diffuse[i] = u_ld[i] * u_kd * max(dot(lightDirection[i], transformedNormals), 0.0);" \
			"reflectionVector[i] = reflect(-lightDirection[i], transformedNormals);" \
			"specular[i] = u_ls[i] * u_ks * pow(max(dot(reflectionVector[i], viewerVector), 0.0), u_materialShininess);" \
			"phong_ads_light += ambient[i] + diffuse[i] + specular[i];" \
			"		}" \
			"	}" \
			"else" \
			"	{" \
			"phong_ads_light = vec3(1.0, 1.0, 1.0);" \
			"	}" \
			"gl_Position = u_projectionMatrix * u_viewMatrix * u_modelMatrix * a_position;" \
			"}";

		GLuint vertexShaderObjectPerVertex = glCreateShader(GL_VERTEX_SHADER);
		glShaderSource(vertexShaderObjectPerVertex, 1, (const GLchar**)&vertexShaderPerVertexSourceCode, NULL);
		glCompileShader(vertexShaderObjectPerVertex);

		GLint statusPv;
		GLint infoLogLengthPv;
		char *logPv = NULL;

		glGetShaderiv(vertexShaderObjectPerVertex, GL_COMPILE_STATUS, &statusPv);
		if (statusPv == GL_FALSE)
		{
			glGetShaderiv(vertexShaderObjectPerVertex, GL_INFO_LOG_LENGTH, &infoLogLengthPv);
			if (infoLogLengthPv > 0)
			{
				logPv = (char *)malloc(infoLogLengthPv);
				if (logPv != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(vertexShaderObjectPerVertex, infoLogLengthPv, &written, logPv);
					fprintf(gpFile, "\n\nPer Vertex Lighting Vertex Shader Compilation Log : %s\n\n", logPv);
					free(logPv);
					logPv = NULL;
					[self uninitialize];
				}
			}
		}

		//Fragment Shader
		const GLchar* fragmentShaderPerVertexSourceCode = 
			"#version 410 core" \
			"\n" \
			"in vec3 phong_ads_light;" \
			"out vec4 FragColor;" \
			"void main(void)" \
			"{" \
			"FragColor = vec4(phong_ads_light, 1.0);" \
			"}";

		GLuint fragmentShaderObjectPerVertex = glCreateShader(GL_FRAGMENT_SHADER);
		glShaderSource(fragmentShaderObjectPerVertex, 1, (const GLchar**)&fragmentShaderPerVertexSourceCode, NULL);
		glCompileShader(fragmentShaderObjectPerVertex);

		statusPv = 0;
		infoLogLengthPv = 0;
		logPv = NULL;

		glGetShaderiv(fragmentShaderObjectPerVertex, GL_COMPILE_STATUS, &statusPv);
		if (statusPv == GL_FALSE)
		{
			glGetShaderiv(fragmentShaderObjectPerVertex, GL_INFO_LOG_LENGTH, &infoLogLengthPv);
			if (infoLogLengthPv > 0)
			{
				logPv = (char*)malloc(infoLogLengthPv);
				if (logPv != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(fragmentShaderObjectPerVertex, infoLogLengthPv, &written, logPv);
					fprintf(gpFile, "\n\nFragment Shader Compilation Log : %s", logPv);
					free(logPv);
					logPv = NULL;
					[self uninitialize];
				}
			}
		}

		//Shader Program object
		shaderProgramObjectPerVertex = glCreateProgram();
		glAttachShader(shaderProgramObjectPerVertex, vertexShaderObjectPerVertex);
		glAttachShader(shaderProgramObjectPerVertex, fragmentShaderObjectPerVertex);
		
		glBindAttribLocation(shaderProgramObjectPerVertex, SDJ_ATTRIBUTE_POSITION, "a_position");
		glBindAttribLocation(shaderProgramObjectPerVertex, SDJ_ATTRIBUTE_NORMAL, "a_normal");

		glLinkProgram(shaderProgramObjectPerVertex);


		//ERROR Checking
		statusPv = 0;
		infoLogLengthPv = 0;
		logPv = NULL;

		glGetProgramiv(shaderProgramObjectPerVertex, GL_LINK_STATUS, &statusPv);
		if (statusPv == GL_FALSE)
		{
			glGetProgramiv(shaderProgramObjectPerVertex, GL_INFO_LOG_LENGTH, &infoLogLengthPv);
			if (infoLogLengthPv > 0)
			{
				logPv = (char*)malloc(infoLogLengthPv);
				if (logPv != NULL)
				{
					GLsizei written;
					glGetProgramInfoLog(shaderProgramObjectPerVertex, infoLogLengthPv, &written, logPv);
					fprintf(gpFile, "\n\nShader Program Link log : %s", logPv);
					free(logPv);
					logPv = NULL;
					[self uninitialize];
				}
			}
		}
		
		//post link steps
		modelMatrixPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_modelMatrix");
		viewMatrixPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_viewMatrix");
		projectionMatrixPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_projectionMatrix");

		laPvUniform[0] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_la[0]");
		ldPvUniform[0] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ld[0]");
		lsPvUniform[0] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ls[0]");
		lightPositionPvUniform[0] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_lightPosition[0]");

		laPvUniform[1] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_la[1]");
		ldPvUniform[1] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ld[1]");
		lsPvUniform[1] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ls[1]");
		lightPositionPvUniform[1] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_lightPosition[1]");

		laPvUniform[2] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_la[2]");
		ldPvUniform[2] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ld[2]");
		lsPvUniform[2] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ls[2]");
		lightPositionPvUniform[2] = glGetUniformLocation(shaderProgramObjectPerVertex, "u_lightPosition[2]");

		kaPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ka");
		kdPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_kd");
		ksPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_ks");
		materialShininessPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_materialShininess");
		lightingEnabledPvUniform = glGetUniformLocation(shaderProgramObjectPerVertex, "u_lightingEnabled");

		/*
		**********PER FRAGMENT LIGHTING SHADER OBJECT**********
		*/

		const GLchar* vertexShaderPerFragmentSourceCode =
			"#version 410 core" \
			"\n" \
			"in vec4 a_position;" \
			"in vec3 a_normal;" \
			"uniform mat4 u_modelMatrix;" \
			"uniform mat4 u_viewMatrix;" \
			"uniform mat4 u_projectionMatrix;" \
			"uniform vec4 u_lightPosition[3];" \
			"uniform int u_lightingEnabled;" \
			"out vec3 transformedNormals;" \
			"out vec3 lightDirection[3];" \
			"out vec3 viewerVector;" \
			"void main(void)" \
			"{" \
			"if (u_lightingEnabled == 1)" \
			"	{" \
			"vec4 eyeCoordinates = u_viewMatrix * u_modelMatrix * a_position;" \
			"mat3 normalMatrix = mat3(u_viewMatrix * u_modelMatrix);" \
			"transformedNormals = normalMatrix * a_normal;" \
			"for (int i = 0; i < 3; i++){" \
			"lightDirection[i] = vec3(u_lightPosition[i]) - eyeCoordinates.xyz;" \
			"}" \
			"viewerVector = -eyeCoordinates.xyz;" \
			"	}" \
			"gl_Position = u_projectionMatrix * u_viewMatrix * u_modelMatrix * a_position;" \
			"}";

		GLuint vertexShaderObjectPerFragment = glCreateShader(GL_VERTEX_SHADER);
		glShaderSource(vertexShaderObjectPerFragment, 1, (const GLchar**)&vertexShaderPerFragmentSourceCode, NULL);
		glCompileShader(vertexShaderObjectPerFragment);

		GLint statusPf;
		GLint infoLogLengthPf;
		char *logPf = NULL;

		glGetShaderiv(vertexShaderObjectPerFragment, GL_COMPILE_STATUS, &statusPf);
		if (statusPf == GL_FALSE)
		{
			glGetShaderiv(vertexShaderObjectPerFragment, GL_INFO_LOG_LENGTH, &infoLogLengthPf);
			if (infoLogLengthPf > 0)
			{
				logPf = (char *)malloc(infoLogLengthPf);
				if (logPf != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(vertexShaderObjectPerFragment, infoLogLengthPf, &written, logPf);
					fprintf(gpFile, "\n\nVertex Shader Compilation Log : %s\n\n", logPf);
					free(logPf);
					logPf = NULL;
					[self uninitialize];
				}
			}
		}

		//Fragment Shader
		const GLchar* fragmentShaderPerFragmentSourceCode =
			"#version 410 core" \
			"\n" \
			"in vec3 transformedNormals;" \
			"in vec3 lightDirection[3];" \
			"in vec3 viewerVector;" \
			"uniform vec3 u_la[3];" \
			"uniform vec3 u_ld[3];" \
			"uniform vec3 u_ls[3];" \
			"uniform vec3 u_ka;" \
			"uniform vec3 u_kd;" \
			"uniform vec3 u_ks;" \
			"uniform float u_materialShininess;" \
			"uniform int u_lightingEnabled;" \
			"out vec4 FragColor;" \
			"void main(void)" \
			"{" \
			"vec3 phong_ads_color;"
			"if (u_lightingEnabled == 1)"
			"{" \
			"vec3 ambient[3];" \
			"vec3 diffuse[3];" \
			"vec3 reflectionVector[3];" \
			"vec3 normalized_light_direction[3];" \
			"vec3 specular[3];" \
			"vec3 normalized_transformed_normals = normalize(transformedNormals);" \
			"vec3 normalized_viewer_vector = normalize(viewerVector);" \
			"for (int i = 0; i < 3; i++){" \
			"ambient[i] = u_la[i] * u_ka;" \
			"normalized_light_direction[i] = normalize(lightDirection[i]);" \
			"diffuse[i] = u_ld[i] * u_kd * max(dot(normalized_light_direction[i], normalized_transformed_normals), 0.0);" \
			"reflectionVector[i] = reflect(-normalized_light_direction[i], normalized_transformed_normals);" \
			"specular[i] = u_ls[i] * u_ks * pow(max(dot(reflectionVector[i], normalized_viewer_vector), 0.0), u_materialShininess);" \
			"phong_ads_color += ambient[i] + diffuse[i] + specular[i];" \
			"}" \
			"}" \
			"else" \
			"{" \
			"phong_ads_color = vec3(1.0, 1.0, 1.0);" \
			"}" \
			"FragColor = vec4(phong_ads_color, 1.0);" \
			"}";

		GLuint fragmentShaderObjectPerFragment = glCreateShader(GL_FRAGMENT_SHADER);
		glShaderSource(fragmentShaderObjectPerFragment, 1, (const GLchar**)&fragmentShaderPerFragmentSourceCode, NULL);
		glCompileShader(fragmentShaderObjectPerFragment);

		statusPf = 0;
		infoLogLengthPf = 0;
		logPf = NULL;

		glGetShaderiv(fragmentShaderObjectPerFragment, GL_COMPILE_STATUS, &statusPf);
		if (statusPf == GL_FALSE)
		{
			glGetShaderiv(fragmentShaderObjectPerFragment, GL_INFO_LOG_LENGTH, &infoLogLengthPf);
			if (infoLogLengthPf > 0)
			{
				logPf = (char*)malloc(infoLogLengthPf);
				if (logPf != NULL)
				{
					GLsizei written;
					glGetShaderInfoLog(fragmentShaderObjectPerFragment, infoLogLengthPf, &written, logPf);
					fprintf(gpFile, "\n\nFragment Shader Compilation Log : %s", logPf);
					free(logPf);
					logPf = NULL;
					[self uninitialize];
				}
			}
		}

		//Shader Program object
		shaderProgramObjectPerFragment = glCreateProgram();
		glAttachShader(shaderProgramObjectPerFragment, vertexShaderObjectPerFragment);
		glAttachShader(shaderProgramObjectPerFragment, fragmentShaderObjectPerFragment);

		glBindAttribLocation(shaderProgramObjectPerFragment, SDJ_ATTRIBUTE_POSITION, "a_position");
		glBindAttribLocation(shaderProgramObjectPerFragment, SDJ_ATTRIBUTE_NORMAL, "a_normal");

		glLinkProgram(shaderProgramObjectPerFragment);


		//ERROR Checking
		statusPf = 0;
		infoLogLengthPf = 0;
		logPf = NULL;

		glGetProgramiv(shaderProgramObjectPerFragment, GL_LINK_STATUS, &statusPf);
		if (statusPf == GL_FALSE)
		{
			glGetProgramiv(shaderProgramObjectPerFragment, GL_INFO_LOG_LENGTH, &infoLogLengthPf);
			if (infoLogLengthPf > 0)
			{
				logPf = (char*)malloc(infoLogLengthPf);
				if (logPf != NULL)
				{
					GLsizei written;
					glGetProgramInfoLog(shaderProgramObjectPerFragment, infoLogLengthPf, &written, logPf);
					fprintf(gpFile, "\n\nShader Program Link log : %s", logPf);
					free(logPf);
					logPf = NULL;
					uninitialize();
				}
			}
		}

		//post link steps
		modelMatrixPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_modelMatrix");
		viewMatrixPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_viewMatrix");
		projectionMatrixPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_projectionMatrix");
		
		laPfUniform[0] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_la[0]");
		ldPfUniform[0] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ld[0]");
		lsPfUniform[0] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ls[0]");
		lightPositionPfUniform[0] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_lightPosition[0]");

		laPfUniform[1] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_la[1]");
		ldPfUniform[1] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ld[1]");
		lsPfUniform[1] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ls[1]");
		lightPositionPfUniform[1] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_lightPosition[1]");

		laPfUniform[2] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_la[2]");
		ldPfUniform[2] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ld[2]");
		lsPfUniform[2] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ls[2]");
		lightPositionPfUniform[2] = glGetUniformLocation(shaderProgramObjectPerFragment, "u_lightPosition[2]");

		kaPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ka");
		kdPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_kd");
		ksPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_ks");
		materialShininessPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_materialShininess");
		lightingEnabledPfUniform = glGetUniformLocation(shaderProgramObjectPerFragment, "u_lightingEnabled");


		//SPHERE DATA ARRAYS INITIALIZATION
		//variable declarations
		float x, y, z;
		float s, t;
		int j, i;
		float du, dv;
		float angleX, angleY;
		GLfloat radius_d;
		GLfloat *position = (GLfloat *)malloc(3 * 3 * 2 * (stacks - 1) * (slices - 1) * sizeof(GLfloat));
		GLfloat *normals = (GLfloat *)malloc(3 * 3 * 2 * (stacks - 1) * (slices - 1) * sizeof(GLfloat));
		GLfloat *texCoords = (GLfloat *)malloc(2 * 3 * 2 * (stacks - 1) * (slices - 1) * sizeof(GLfloat));
		
		//code
		du = 2.0f * M_PI / (float)(slices - 1);
		dv = 1.0f * M_PI / (float)(stacks - 1);

		int vertexptr = 0;
		for (i = 0; i < stacks - 1; i++)
		{
			for (j = 0; j < slices - 1; j++)
			{
				//face 1 ##########
				//1
				//radius_d = radius - 0.03;
				a = i;
				b = j;
				angleX = M_PI / 2.0f - (a * dv);
				angleY = b * du;

				x = cos(angleX) * sin(angleY);
				y = sin(angleX);
				z = cos(angleX) * cos(angleY);
				
				s = (float)b / (float)(slices - 1);
				t = (float)a / (float)(stacks - 1);

				position[3 * vertexptr + 0] = x * radius;
				position[3 * vertexptr + 1] = y * radius;
				position[3 * vertexptr + 2] = z * radius;

				normals[3 * vertexptr + 0] = x * radius;
				normals[3 * vertexptr + 1] = y * height;
				normals[3 * vertexptr + 2] = z * radius;

				texCoords[2 * vertexptr + 0] = s;
				texCoords[2 * vertexptr + 1] = t;

				vertexptr++;

				//2
				a = i + 1;
				b = j;
				angleX = M_PI / 2.0f - (a * dv);
				angleY = b * du;
				x = cos(angleX) * sin(angleY);
				y = sin(angleX);
				z = cos(angleX) * cos(angleY);

				s = (float)b / (float)(slices - 1);
				t = (float)a / (float)(stacks - 1);

				position[3 * vertexptr + 0] = x * radius;
				position[3 * vertexptr + 1] = y * radius;
				position[3 * vertexptr + 2] = z * radius;

				normals[3 * vertexptr + 0] = x * radius;
				normals[3 * vertexptr + 1] = y * height;
				normals[3 * vertexptr + 2] = z * radius;

				texCoords[2 * vertexptr + 0] = s;
				texCoords[2 * vertexptr + 1] = t;

				vertexptr++;

				//3
				a = i;
				b = j + 1;
				angleX = M_PI / 2.0f - (a * dv);
				angleY = b * du;
				x = cos(angleX) * sin(angleY);
				y = sin(angleX);
				z = cos(angleX) * cos(angleY);

				s = (float)b / (float)(slices - 1);
				t = (float)a / (float)(stacks - 1);

				position[3 * vertexptr + 0] = x * radius;
				position[3 * vertexptr + 1] = y * radius;
				position[3 * vertexptr + 2] = z * radius;

				normals[3 * vertexptr + 0] = x * radius;
				normals[3 * vertexptr + 1] = y * height;
				normals[3 * vertexptr + 2] = z * radius;

				texCoords[2 * vertexptr + 0] = s;
				texCoords[2 * vertexptr + 1] = t;

				vertexptr++;

				//face 2 ##########
				//1
				a = i + 1;
				b = j;
				angleX = M_PI / 2.0f - (a * dv);
				angleY = b * du;
				x = cos(angleX) * sin(angleY);
				y = sin(angleX);
				z = cos(angleX) * cos(angleY);

				s = (float)b / (float)(slices - 1);
				t = (float)a / (float)(stacks - 1);

				position[3 * vertexptr + 0] = x * radius;
				position[3 * vertexptr + 1] = y * radius;
				position[3 * vertexptr + 2] = z * radius;

				normals[3 * vertexptr + 0] = x * radius;
				normals[3 * vertexptr + 1] = y * height;
				normals[3 * vertexptr + 2] = z * radius;

				texCoords[2 * vertexptr + 0] = s;
				texCoords[2 * vertexptr + 1] = t;

				vertexptr++;

				//2
				a = i + 1;
				b = j + 1;
				angleX = M_PI / 2.0f - (a * dv);
				angleY = b * du;
				x = cos(angleX) * sin(angleY);
				y = sin(angleX);
				z = cos(angleX) * cos(angleY);

				s = (float)b / (float)(slices - 1);
				t = (float)a / (float)(stacks - 1);

				position[3 * vertexptr + 0] = x * radius;
				position[3 * vertexptr + 1] = y * radius;
				position[3 * vertexptr + 2] = z * radius;

				normals[3 * vertexptr + 0] = x * radius;
				normals[3 * vertexptr + 1] = y * height;
				normals[3 * vertexptr + 2] = z * radius;

				texCoords[2 * vertexptr + 0] = s;
				texCoords[2 * vertexptr + 1] = t;

				vertexptr++;

				//3
				a = i;
				b = j + 1;
				angleX = M_PI / 2.0f - (a * dv);
				angleY = b * du;
				x = cos(angleX) * sin(angleY);
				y = sin(angleX);
				z = cos(angleX) * cos(angleY);

				s = (float)b / (float)(slices - 1);
				t = (float)a / (float)(stacks - 1);

				position[3 * vertexptr + 0] = x * radius;
				position[3 * vertexptr + 1] = y * radius;
				position[3 * vertexptr + 2] = z * radius;

				normals[3 * vertexptr + 0] = x * radius;
				normals[3 * vertexptr + 1] = y * height;
				normals[3 * vertexptr + 2] = z * radius;

				texCoords[2 * vertexptr + 0] = s;
				texCoords[2 * vertexptr + 1] = t;

				vertexptr++;
			}

			//radius -= 0.03f;
		}

		//vertex array object
		size_t size = 3 * 2 * (stacks - 1) * (slices - 1) * sizeof(GLfloat);
		glGenVertexArrays(1, &vao);
		glBindVertexArray(vao);

			//vertex buffer object for ___position___
			glGenBuffers(1, &vbo_position);
			glBindBuffer(GL_ARRAY_BUFFER, vbo_position);

			glBufferData(GL_ARRAY_BUFFER, 3 * size, position, GL_STATIC_DRAW);
			glVertexAttribPointer(SDJ_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL);
			glEnableVertexAttribArray(SDJ_ATTRIBUTE_POSITION);

			glBindBuffer(GL_ARRAY_BUFFER, 0);

			//vertex buffer object for ___normals___
			glGenBuffers(1, &vbo_normals);
			glBindBuffer(GL_ARRAY_BUFFER, vbo_normals);

			glBufferData(GL_ARRAY_BUFFER, 3 * size, normals, GL_STATIC_DRAW);
			glVertexAttribPointer(SDJ_ATTRIBUTE_NORMAL, 3, GL_FLOAT, GL_FALSE, 0, NULL);
			glEnableVertexAttribArray(SDJ_ATTRIBUTE_NORMAL);

			glBindBuffer(GL_ARRAY_BUFFER, 0);

		//unbind vao
		glBindVertexArray(0);

		vertexCount = vertexptr;

		glClearDepth(1.0f);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		
		lights[0].lightAmbient = vec4(0.0f, 0.0f, 0.0f, 1.0f);
		lights[0].lightDiffuse = vec4(1.0f, 0.0f, 0.0f, 1.0f);
		lights[0].lightSpecular = vec4(1.0f, 0.0f, 0.0f, 1.0f);
		lights[0].lightPosition = vec4(2.0f, 0.0f, 0.0f, 0.0f);

		lights[1].lightAmbient = vec4(0.0f, 0.0f, 0.0f, 1.0f);
		lights[1].lightDiffuse = vec4(0.0f, 1.0f, 0.0f, 1.0f);
		lights[1].lightSpecular = vec4(0.0f, 1.0f, 0.0f, 1.0f);
		lights[1].lightPosition = vec4(0.0f, 2.0f, 0.0f, 0.0f);

		lights[2].lightAmbient = vec4(0.0f, 0.0f, 0.0f, 1.0f);
		lights[2].lightDiffuse = vec4(0.0f, 0.0f, 1.0f, 1.0f);
		lights[2].lightSpecular = vec4(0.0f, 0.0f, 1.0f, 1.0f);
		lights[2].lightPosition = vec4(0.0f, 0.0f, 2.0f, 0.0f);
		
		perspectiveProjectionMatrix = mat4::identity();
		return 0;
	}

	//overriden
	-(void)reshape
	{
		//code
		[super reshape];
		CGLLockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
		NSRect rect = [self bounds];
		int width = rect.size.width;
		int height = rect.size.height;

		//call our resize
		[self resize:width :height];

		CGLUnlockContext((CGLContextObj)[[self openGLContext] CGLContextObj]);
	}

	-(void)resize:(int)width :(int)height
	{
		//code
		if (height < 0)
			height = 1;
		
		glViewport(0, 0, (GLsizei)width, (GLsizei)height);

		perspectiveProjectionMatrix = vmath::perspective(
			45.0, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
	}

	-(void)display
	{
		//code
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//use shader program object
		if (bPerFragment == true)
		{
			glUseProgram(shaderProgramObjectPerFragment);
		}
		else
		{
			glUseProgram(shaderProgramObjectPerVertex);
		}

		//transformations
		mat4 translationMatrix = translate(0.0f, 0.0f, -2.0f);
		mat4 modelMatrix = mat4::identity();
		mat4 viewMatrix = mat4::identity();
		
		modelMatrix = translationMatrix;
		
		glUniformMatrix4fv(modelMatrixPvUniform, 1, GL_FALSE, modelMatrix);
		glUniformMatrix4fv(viewMatrixPvUniform, 1, GL_FALSE, viewMatrix);
		glUniformMatrix4fv(projectionMatrixPvUniform, 1, GL_FALSE, perspectiveProjectionMatrix);

		glUniformMatrix4fv(modelMatrixPfUniform, 1, GL_FALSE, modelMatrix);
		glUniformMatrix4fv(viewMatrixPfUniform, 1, GL_FALSE, viewMatrix);
		glUniformMatrix4fv(projectionMatrixPfUniform, 1, GL_FALSE, perspectiveProjectionMatrix);

		if (bPerVertex == true && bLight == true)
		{
			glUniform1i(lightingEnabledPvUniform, 1);
			//glUniform1i(lightingEnabledPfUniform, 0);
			glUniform3fv(laPvUniform[0], 1, lights[0].lightAmbient);
			glUniform3fv(ldPvUniform[0], 1, lights[0].lightDiffuse);
			glUniform3fv(lsPvUniform[0], 1, lights[0].lightSpecular);
			lights[0].lightPosition = vec4((GLfloat)(r * cosf(angleSphere)), 0.0f, (GLfloat)(r * sinf(angleSphere)), 0.0f);
			glUniform4fv(lightPositionPvUniform[0], 1, lights[0].lightPosition);

			glUniform3fv(laPvUniform[1], 1, lights[1].lightAmbient);
			glUniform3fv(ldPvUniform[1], 1, lights[1].lightDiffuse);
			glUniform3fv(lsPvUniform[1], 1, lights[1].lightSpecular);
			lights[1].lightPosition = vec4((GLfloat)(r * cosf(angleSphere)), (GLfloat)(r * sinf(angleSphere)), 0.0f, 0.0f);
			glUniform4fv(lightPositionPvUniform[1], 1, lights[1].lightPosition);

			glUniform3fv(laPvUniform[2], 1, lights[2].lightAmbient);
			glUniform3fv(ldPvUniform[2], 1, lights[2].lightDiffuse);
			glUniform3fv(lsPvUniform[2], 1, lights[2].lightSpecular);
			lights[2].lightPosition = vec4(0.0f, (GLfloat)(r * cosf(angleSphere)), (GLfloat)(r * sinf(angleSphere)), 0.0f);
			glUniform4fv(lightPositionPvUniform[2], 1, lights[2].lightPosition);

			glUniform3fv(kaPvUniform, 1, materialAmbient);
			glUniform3fv(kdPvUniform, 1, materialDiffuse);
			glUniform3fv(ksPvUniform, 1, materialSpecular);
			glUniform1f(materialShininessPvUniform, materialShininess);
		}
		if (bPerFragment == true && bLight == true)
		{
			//glUniform1i(lightingEnabledPvUniform, 0);
			glUniform3fv(laPfUniform[0], 1, lights[0].lightAmbient);
			glUniform3fv(ldPfUniform[0], 1, lights[0].lightDiffuse);
			glUniform3fv(lsPfUniform[0], 1, lights[0].lightSpecular);
			lights[0].lightPosition = vec4((GLfloat)(r * cosf(angleSphere)), 0.0f, (GLfloat)(r * sinf(angleSphere)), 0.0f);
			glUniform4fv(lightPositionPfUniform[0], 1, lights[0].lightPosition);

			glUniform3fv(laPfUniform[1], 1, lights[1].lightAmbient);
			glUniform3fv(ldPfUniform[1], 1, lights[1].lightDiffuse);
			glUniform3fv(lsPfUniform[1], 1, lights[1].lightSpecular);
			lights[1].lightPosition = vec4((GLfloat)(r * cosf(angleSphere)), (GLfloat)(r * sinf(angleSphere)), 0.0f, 0.0f);
			glUniform4fv(lightPositionPfUniform[1], 1, lights[1].lightPosition);

			glUniform3fv(laPfUniform[2], 1, lights[2].lightAmbient);
			glUniform3fv(ldPfUniform[2], 1, lights[2].lightDiffuse);
			glUniform3fv(lsPfUniform[2], 1, lights[2].lightSpecular);
			lights[2].lightPosition = vec4(0.0f, (GLfloat)(r * cosf(angleSphere)), (GLfloat)(r * sinf(angleSphere)), 0.0f);
			glUniform4fv(lightPositionPfUniform[2], 1, lights[2].lightPosition);

			glUniform3fv(kaPfUniform, 1, materialAmbient);
			glUniform3fv(kdPfUniform, 1, materialDiffuse);
			glUniform3fv(ksPfUniform, 1, materialSpecular);
			glUniform1f(materialShininessPfUniform, materialShininess);
		}
		else if (bLight == false)
		{
			glUniform1i(lightingEnabledPvUniform, 0);
			glUniform1i(lightingEnabledPfUniform, 0);
		}

		//bind vao
		glBindVertexArray(vao);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo_sphere_element);
		glDrawElements(GL_TRIANGLES, numElements, GL_UNSIGNED_SHORT, 0);

		//unbind vao
		glBindVertexArray(0);

		//unuse the shader program object
		glUseProgram(0);

		//unuse the shader program object
		glUseProgram(0);
	}

	-(void)myupdate
	{
		//code
		if (bToggleRotate == true)
		{
			angleSphere += 0.003f;
			if (angleSphere > 2 * M_PI)
				angleSphere -= 2 * M_PI;
		}
	}

	-(void)uninitialize
	{
		//code
		//deletion and uninitialization of vbo
		if (vbo_normals)
		{
			glDeleteVertexArrays(1, &vbo_normals);
			vbo_normals = 0;
		}

		if (vbo_position)
		{
			glDeleteBuffers(1, &vbo_position);
			vbo_position = 0;
		}

		if (vao)
		{
			glDeleteVertexArrays(1, &vao);
			vao = 0;
		}

		//shader uninitialization
		if (shaderProgramObject)
		{
			glUseProgram(shaderProgramObject);
			GLsizei numAttachedShaders;
			glGetProgramiv(shaderProgramObject, GL_ATTACHED_SHADERS, &numAttachedShaders);
			GLuint *shaderObjects = NULL;
			shaderObjects = (GLuint *)malloc(numAttachedShaders * sizeof(GLuint));

			//filling empty buffer with shader objects
			glGetAttachedShaders(shaderProgramObject, numAttachedShaders, &numAttachedShaders, shaderObjects);

			for (GLsizei i = 0; i < numAttachedShaders; i++)
			{
				glDetachShader(shaderProgramObject, shaderObjects[i]);
				glDeleteShader(shaderObjects[i]);
				shaderObjects[i] = 0;
			}

			free(shaderObjects);
			shaderObjects = NULL;
			glUseProgram(0);
			glDeleteProgram(shaderProgramObject);
			shaderProgramObject = 0;
		}
	}

	-(BOOL)acceptsFirstResponder
	{
		//code
		[[self window]makeFirstResponder:self];

		return YES;
	}

	-(void)keyDown:(NSEvent *)event
	{
		//code
		int key = (int)[[event characters]characterAtIndex:0];

		switch(key)
		{
		case 'Q':
		case 'q':
			[self uninitialize];
			[self release];
			[NSApp terminate:self];
			break;
		case 27:
			[[self window] toggleFullScreen:self];
			if (gbFullscreen == false)
				gbFullscreen = true;
			else
				gbFullscreen = false;
			break;

		case 'F':
		case 'f':
			if (bPerFragment == false && bLight == true)
			{
				bPerFragment = true;
				bPerVertex = false;
			}
			else if (bPerFragment == true && bLight == true)
			{
				bPerFragment = false;
				bPerVertex = true;
			}
			break;

		case 'v':
		case 'V':
			if (bPerVertex == false && bLight == true)
			{
				bPerFragment = false;
				bPerVertex = true;
			}
			break;

		case 'L':
		case 'l':
			if (bLight == false)
			{
				bLight = true;
				bPerVertex = true;
				bPerFragment = false;
				bToggleRotate = true;
			}
			else if (bLight == true)
			{
				bLight = false;
				bPerVertex = false;
				bPerFragment = false;
				bToggleRotate = false;
			}
			break;
			
		default:
			break;
		}
	}

	-(void)mouseDown:(NSEvent *)event
	{
		//code

	}

	-(void)dealloc
	{
		//code
		[super dealloc];

		if (displayLink)
		{
			CVDisplayLinkStop(displayLink);
			CVDisplayLinkRelease(displayLink);
			displayLink = nil;
		}
	}
@end

//implement display link callback function
CVReturn myDisplayLinkCallback(CVDisplayLinkRef displayLink, const CVTimeStamp *currentTime, const CVTimeStamp *outputTime, CVOptionFlags flagsIn, CVOptionFlags *flagsOut, void *view)
{
	//code
	CVReturn result = [(GLView *)view getFrameForTime:outputTime];

	return result;
}
