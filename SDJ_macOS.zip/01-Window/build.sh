clang -o Window Window.m -framework Cocoa
