//header files
#import <foundation/foundation.h>
#import <cocoa/cocoa.h>

//global variable declarations

//interface declarations
@interface AppDelegate:NSObject <NSApplicationDelegate, NSWindowDelegate>
@end

// @interface myView:NSView
// @end

//entry point function
int main (int argc, char *argv[])
{
    //code
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];     //create autorelease pool
    NSApp = [NSApplication sharedApplication];

    //create app delegate object
    AppDelegate *appDelegate = [[AppDelegate alloc] init];

    //give the app delegate to NSApp
    [NSApp setDelegate:appDelegate];

    //start run(game) loop
    [NSApp run];

    //tell autorelease pool to release all objects created by this application
    [pool release];

    return 0;
}

//implementation of app delegate
@implementation AppDelegate 
{
    @private
    NSWindow *window;
}
-(void)applicationDidFinishLaunching:(NSNotification *)notification
{
    //code
    NSRect rect = NSMakeRect(0.0, 0.0, 800.0, 600.0);

    window = [[NSWindow alloc] initWithContentRect:rect 
        StyleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable 
        Backing:NSBackingStoreBuffered 
        Defer:NO];
    
    [window setTitle:@"macOS Window : SDJ"];

    //set background color
    NSColor *bkColor = [NSColor BlackColor];
    [window setBackgroundColor:bkColor];
    [window center];
    [window setDelegate:self];      //set window's delegate to this object
    [window makeKeyAndOrderFront:self];
}

-(void)applicationWillTerminate:(NSNotification *)notification
{
    //code

}

-(void)windowWillClose:(NSNotification *)notification
{
    //code
    [NSApp terminate:self];
}

-(void)dealloc
{
    //code
    if (window)
    {
        [window release];
        window = nil;
    }
    [super dealloc];
}
@end
